<?php

define('DB_NAME', 'capstone');
define('DB_PASSWORD', '');
define('DB_USER', 'root');
define('ROOT_FOLDER', $_SERVER['DOCUMENT_ROOT'] . '/capstone');


?>