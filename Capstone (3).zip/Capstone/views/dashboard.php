<?php
include_once '../CAPSTONE/templates/dash.php';

?>
<main>

    <div class="info-data">
        <div class="infocard">
            <div class="head">
                <div>
                    <!-- <img src="#" alt="logo" id="data">" -->
                    <h2></h2>
                    <p></p>
                </div>
                <i class="bx bx-trending-up icon"></i>
            </div>

        </div>
        <div class="infocard">
            <div class="head">
                <div>
                    <!-- <img src="#" alt="logo" id="data">" -->
                    <h2></h2>
                    <p></p>
                </div>
                <i class="bx bx-trending-down icon down"></i>
            </div>

        </div>
        <div class="infocard">
            <div class="head">
                <div>
                    <!-- <img src="#" alt="logo" id="data">" -->
                    <h2></h2>
                    <p></p>
                </div>
                <i class="bx bx-trending-down icon down"></i>
            </div>

        </div>
        <div class="infocard">
            <div class="head">
                <div>
                    <!-- <img src="#" alt="logo" id="data">" -->
                    <h2> </h2>
                    <p></p>
                </div>
                <i class="bx bx-trending-up icon"></i>
            </div>

        </div>
        <div class="infocard">
            <div class="head">
                <div>
                    <!-- <img src="#" alt="logo" id="data">" -->
                    <h2></h2>
                    <p></p>
                </div>
                <i class="bx bx-trending-up icon"></i>
            </div>

        </div>
    </div>